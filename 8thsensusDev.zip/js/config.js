var webConfig = {
   'dataLakeUrl': 'https://8thsensus.eng.macrometa.io:8080',
   'key': '%$%$#5454354343trqt34rtrfwrgrfSFGFfgGSDFSFDSFDSFD',
   'customerFilter': 'eve11KEW9258'
}